import newsRouter from './news'
import siteRouter from './site'
import userRouter from './user'


function route(app) {
    app.use('/users', userRouter)
    app.use('/news', newsRouter)
    app.use('/', siteRouter)
}

module.exports = route
